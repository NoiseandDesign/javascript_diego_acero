var calculadora= {

pantalla: document.getElementById('display'),
valpantalla: "0",
operaciones: "",
num1: 0,
num2: 0,
numfin: 0,
resultado: 0,
igual: false,

init: (function(){
	this.eventos();
}),

eventos: function(){
	document.getElementById('0').onclick=(function() {calculadora.teclaNum("0");});
	document.getElementById("1").onclick=(function() {calculadora.teclaNum("1");});
	document.getElementById('2').onclick=(function() {calculadora.teclaNum("2");});
	document.getElementById('3').onclick=(function() {calculadora.teclaNum("3");});
	document.getElementById('4').onclick=(function() {calculadora.teclaNum("4");});
	document.getElementById('5').onclick=(function() {calculadora.teclaNum("5");});
	document.getElementById('6').onclick=(function() {calculadora.teclaNum("6");});
	document.getElementById('7').onclick=(function() {calculadora.teclaNum("7");});
	document.getElementById('8').onclick=(function() {calculadora.teclaNum("8");}); 
	document.getElementById('9').onclick=(function() {calculadora.teclaNum("9");});
	document.getElementById('on').onclick=(function() {calculadora.displayini();});
	document.getElementById('igual').onclick=(function() {calculadora.mostrarResultado();});
	document.getElementById('punto').onclick=(function() {calculadora.punto();});
	document.getElementById('sign').onclick=(function() {calculadora.signomenos();});
	document.getElementById('mas').onclick=(function() {calculadora.teclaOperacion("+");});
	document.getElementById('menos').onclick=(function() {calculadora.teclaOperacion("-");});
	document.getElementById('por').onclick=(function() {calculadora.teclaOperacion("*");});
	document.getElementById('dividido').onclick=(function() {calculadora.teclaOperacion("/");});	                             
},

displayini: function(){
	this.valpantalla = "0";
	this.operaciones = "";
	this.op = "";
	this.num1 = 0;
	this.num2 = 0;
	this.numfin = 0;
	this.resultado = 0;
	this.igual = false;
	this.actualizarResultado();
},

teclaNum: function(val){
	if(this.valpantalla.length < 8){
		if(this.valpantalla=="0"){
			this.valpantalla = "";
			this.valpantalla = this.valpantalla + val;
		}else{
			this.valpantalla = this.valpantalla + val;
}
this.actualizarResultado();
	}
},

teclaOperacion: function(opera){
	this.num1 = parseFloat(this.valpantalla);
	this.valpantalla = "";
	this.operaciones = opera;
	this.igual = false;
	this.actualizarResultado();
},

mostrarResultado: function(){
	if(!this.igual){
		this.num2 = parseFloat(this.valpantalla);
		this.numfin = this.num2;
		this.calcula(this.num1, this.num2, this.operaciones);
	}else{this.calcula(this.num1, this.numfin, this.operaciones);
	}
	this.num1 = this.resultado;
	this.valpantalla = "";
	if(this.resultado.toString().length < 9){
		this.valpantalla = this.resultado.toString();
	}else{
		this.valpantalla = this.resultado.toString().slice(0,8) + "...";
	}
	this.igual = true;
	this.actualizarResultado();
	},
	
	calcula: function(num1, num2, operaciones){
		switch(operaciones){
			case "+":
			this.resultado = eval(num1 + num2);
			break;
			case "-":
			this.resultado = eval (num1 - num2);
			break;
			case "*":
			this.resultado = eval (num1 * num2);
			break;
			case "/":
			this.resultado = eval (num1 / num2);
		}
	},
	actualizarResultado: function(){
		this.pantalla.innerHTML = this.valpantalla; 
	},
	
	punto: function(){
		if(this.valpantalla.indexOf(".")== -1){
			if(this.valpantalla == ""){
				this.valpantalla = this.valpantalla + "0.";
			}else{
				this.valpantalla = this.valpantalla + ".";
			}
			this.actualizarResultado();
		}
	},
	
	signomenos: function(){
		if(this.valpantalla != "0"){
			var tecmen;
			if(this.valpantalla.charAt(0)=="-"){
				tecmen = this.valpantalla.slice(1);
			}else{
				tecmen = "-" + this.valpantalla;
	}
	this.valpantalla = "";
	this.valpantalla = tecmen;
	this.actualizarResultado();
		}
	}
	
};

calculadora.init();


/*--------------------------cambio-teclas----------------------------------*/

function cambioTeclasOn(){
	document.getElementById('on').style="width:21%;";
}
function originalTeclasOn(){	
	document.getElementById('on').style="width:22%;";
}
document.getElementById('on').onmousedown=cambioTeclasOn;
document.getElementById('on').onmouseup=originalTeclasOn;

function cambioTeclasSign(){
	document.getElementById('sign').style="width:21%;";
}
function originalTeclasSign(){	
	document.getElementById('sign').style="width:22%;";
}
document.getElementById('sign').onmousedown=cambioTeclasSign;
document.getElementById('sign').onmouseup=originalTeclasSign;

function cambioTeclasRaiz(){
	document.getElementById('raiz').style="width:21%;";
}
function originalTeclasRaiz(){	
	document.getElementById('raiz').style="width:22%;";
}
document.getElementById('raiz').onmousedown=cambioTeclasRaiz;
document.getElementById('raiz').onmouseup=originalTeclasRaiz;

function cambioTeclasDividido(){
	document.getElementById('dividido').style="width:21%;";
}
function originalTeclasDividido(){	
	document.getElementById('dividido').style="width:22%;";
}
document.getElementById('dividido').onmousedown=cambioTeclasDividido;
document.getElementById('dividido').onmouseup=originalTeclasDividido;

function cambioTeclas7(){
	document.getElementById('7').style="width:21%;";
}
function originalTeclas7(){	
	document.getElementById('7').style="width:22%;";
}
document.getElementById('7').onmousedown=cambioTeclas7;
document.getElementById('7').onmouseup=originalTeclas7;

function cambioTeclas8(){
	document.getElementById('8').style="width:21%;";
}
function originalTeclas8(){	
	document.getElementById('8').style="width:22%;";
}
document.getElementById('8').onmousedown=cambioTeclas8;
document.getElementById('8').onmouseup=originalTeclas8;

function cambioTeclas9(){
	document.getElementById('9').style="width:21%;";
}
function originalTeclas9(){	
	document.getElementById('9').style="width:22%;";
}
document.getElementById('9').onmousedown=cambioTeclas9;
document.getElementById('9').onmouseup=originalTeclas9;

function cambioTeclasPor(){
	document.getElementById('por').style="width:21%;";
}
function originalTeclasPor(){	
	document.getElementById('por').style="width:22%;";
}
document.getElementById('por').onmousedown=cambioTeclasPor;
document.getElementById('por').onmouseup=originalTeclasPor;

function cambioTeclas4(){
	document.getElementById('4').style="width:21%;";
}
function originalTeclas4(){	
	document.getElementById('4').style="width:22%;";
}
document.getElementById('4').onmousedown=cambioTeclas4;
document.getElementById('4').onmouseup=originalTeclas4;

function cambioTeclas5(){
	document.getElementById('5').style="width:21%;";
}
function originalTeclas5(){	
	document.getElementById('5').style="width:22%;";
}
document.getElementById('5').onmousedown=cambioTeclas5;
document.getElementById('5').onmouseup=originalTeclas5;

function cambioTeclas6(){
	document.getElementById('6').style="width:21%;";
}
function originalTeclas6(){	
	document.getElementById('6').style="width:22%;";
}
document.getElementById('6').onmousedown=cambioTeclas6;
document.getElementById('6').onmouseup=originalTeclas6;

function cambioTeclasMenos(){
	document.getElementById('menos').style="width:21%;";
}
function originalTeclasMenos(){	
	document.getElementById('menos').style="width:22%;";
}
document.getElementById('menos').onmousedown=cambioTeclasMenos;
document.getElementById('menos').onmouseup=originalTeclasMenos;

function cambioTeclas1(){
	document.getElementById('1').style="width:29%;";
}
function originalTeclas1(){	
	document.getElementById('1').style="width:30%;";
}
document.getElementById('1').onmousedown=cambioTeclas1;
document.getElementById('1').onmouseup=originalTeclas1;

function cambioTeclas2(){
	document.getElementById('2').style="width:29%;";
}
function originalTeclas2(){	
	document.getElementById('2').style="width:30%;";
}
document.getElementById('2').onmousedown=cambioTeclas2;
document.getElementById('2').onmouseup=originalTeclas2;

function cambioTeclas3(){
	document.getElementById('3').style="width:29%;";
}
function originalTeclas3(){	
	document.getElementById('3').style="width:30%;";
}
document.getElementById('3').onmousedown=cambioTeclas3;
document.getElementById('3').onmouseup=originalTeclas3;

function cambioTeclas0(){
	document.getElementById('0').style="width:29%;";
}
function originalTeclas0(){	
	document.getElementById('0').style="width:30%;";
}
document.getElementById('0').onmousedown=cambioTeclas0;
document.getElementById('0').onmouseup=originalTeclas0;

function cambioTeclasPunto(){
	document.getElementById('punto').style="width:29%;";
}
function originalTeclasPunto(){	
	document.getElementById('punto').style="width:30%;";
}
document.getElementById('punto').onmousedown=cambioTeclasPunto;
document.getElementById('punto').onmouseup=originalTeclasPunto;

function cambioTeclasIgual(){
	document.getElementById('igual').style="width:29%;";
}
function originalTeclasIgual(){	
	document.getElementById('igual').style="width:30%;";
}
document.getElementById('igual').onmousedown=cambioTeclasIgual;
document.getElementById('igual').onmouseup=originalTeclasIgual;

function cambioTeclasMas(){
	document.getElementById('mas').style="width:89%;";
}
function originalTeclasMas(){	
	document.getElementById('mas').style="width:90%;";
}
document.getElementById('mas').onmousedown=cambioTeclasMas;
document.getElementById('mas').onmouseup=originalTeclasMas;





